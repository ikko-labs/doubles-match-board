# ダブルス試合表

スマホのブラウザで使うダブルスの試合表です。QRコードを読むだけで、ログインなしで同じ画面を見られます。

## 公開手順（Vercel）

1. このフォルダを新しいGitリポジトリにして push します。
2. Vercel の「Add New → Project」でそのリポジトリを読み込み、設定は変えずに Deploy します。
3. Vercel Marketplace の Upstash for Redis をインストールし、リージョンに日本（東京）を選んで、このプロジェクトに接続します。
4. 「Deployments」から最新のデプロイを Redeploy します（接続情報を反映するため）。

トップページの「お試し版です」という表示が消えていれば、同期が有効です。

## ファイル

- `index.html` … 画面と組み合わせの計算
- `api/room.js` … 同期API
- `vercel.json` … 同期APIを東京リージョンで動かす設定
- 環境変数 `KV_REST_API_URL` / `KV_REST_API_TOKEN`（または `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`）は、手順3で自動設定されます。

## 仕様メモ

- 閲覧用QRは誰でも見られ、途中参加もできます。タイマーや進行の操作は操作用リンクを持つ人だけができます。
- 各スマホは3秒ごとに更新を確認します。
- 試合表は最後の更新から3日で自動削除されます。
